<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Divisiones;

class DivisionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $division = new Divisiones;
        $division->nombre_division = "AFC North";
        $division->logo = "derte";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "AFC South";
        $division->logo = "derte";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "AFC East";
        $division->logo = "qwdede";
        $division->sb_division = 20;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "AFC West";
        $division->logo = "derte";
        $division->sb_division = 20;
        $division->save();

        #NFC

        $division = new Divisiones;
        $division->nombre_division = "NFC North";
        $division->logo = "wertd";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "NFC South";
        $division->logo = "werdt";
        $division->sb_division = 25;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "NFC East";
        $division->logo = "iojds";
        $division->sb_division = 20;
        $division->save();

        $division = new Divisiones;
        $division->nombre_division = "NFC West";
        $division->logo = "isdsd";
        $division->sb_division = 20;
        $division->save();
       
    }
}
